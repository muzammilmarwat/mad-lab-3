package com.example.jokesprovider

import androidx.lifecycle.ViewModel

class JokeListViewModel: ViewModel() {

}